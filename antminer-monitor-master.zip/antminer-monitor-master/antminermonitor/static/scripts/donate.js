CoinWidgetCom.go({

    /* make sure you update the wallet_address or you will not get your donations */
    wallet_address: "1HYCBovF6mqqKMyG4m2DQxXpdKmogK4Wuw"

    , currency: "bitcoin"
    , counter: "hide"
    , alignment: "br"
    , qrcode: true
    , auto_show: false
    , lbl_button: "Donate"
    , lbl_address: "Donate Bitcoin to this Address:"
    , lbl_count: "donations"
    , lbl_amount: "BTC"
});
CoinWidgetCom.go({

    /* make sure you update the wallet_address or you will not get your donations */
    wallet_address: "LLrjq6nRokS74yPMspitHkXv4nLtEyebNW"

    , currency: "litecoin"
    , counter: "hide"
    , alignment: "ar"
    , qrcode: true
    , auto_show: false
    , lbl_button: "Donate"
    , lbl_address: "Donate Litecoin to this Address:"
    , lbl_count: "donations"
    , lbl_amount: "LTC"
});
CoinWidgetCom.go({

    /* make sure you update the wallet_address or you will not get your donations */
    wallet_address: "XuEnZtsCmWcDwKVe82wQddsfwUifXyeRoQ"

    , currency: "dash"
    , counter: "hide"
    , alignment: "bl"
    , qrcode: true
    , auto_show: false
    , lbl_button: "Donate"
    , lbl_address: "Donate Dash to this Address:"
    , lbl_count: "donations"
    , lbl_amount: "DASH"
});
CoinWidgetCom.go({

    /* make sure you update the wallet_address or you will not get your donations */
    wallet_address: "0x5bD8813Da5148fbc841bB18b9411fF72EdC8e10a"

    , currency: "ethereum"
    , counter: "hide"
    , alignment: "al"
    , qrcode: true
    , auto_show: false
    , lbl_button: "Donate"
    , lbl_address: "Donate Ethereum to this Address:"
    , lbl_count: "donations"
    , lbl_amount: "ETHEREUM"
});
